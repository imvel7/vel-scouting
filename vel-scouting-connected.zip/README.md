# Vel Scouting

Vel Scouting public player directory and published scouting report viewer.

## Files
- `index.html` - static website for GitHub Pages
- `vel_access_setup.sql` - Supabase row-level security and staff access policies
- `KURULUM.md` - Turkish mobile setup guide

Read `KURULUM.md` before publishing. Never put a Supabase `service_role` or secret key in the website source.


Supabase project URL and publishable key are configured in `index.html`. The publishable key is intended for browser use; never add a Supabase secret/service-role key to this repository.
